﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_Herencia
{
    public class Super_Poderes:Personaje
    {
        public bool Volar { get; set; }
        public bool SuperFuerza { get; set; }
        public bool Telequinesis { get; set; }
        public bool Velocidad { get; set; }
    }
}
