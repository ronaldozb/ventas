﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_Herencia
{
    public class Villano:Super_Poderes
    {
        public int NiveldeMaldad { get; set; }
    }
}
